export default {
  apiKey: "AIzaSyBwwSYtb4BMTQih1oLSlgWU4lF5sbiXcdk",
  authDomain: "payment-gateways-stripe.firebaseapp.com",
  projectId: "payment-gateways-stripe",
  storageBucket: "payment-gateways-stripe.appspot.com",
  messagingSenderId: "577467083591",
  appId: "1:577467083591:web:ffaba7fe2348648e15fa62",
  measurementId: "G-Q2553SHW24"
};