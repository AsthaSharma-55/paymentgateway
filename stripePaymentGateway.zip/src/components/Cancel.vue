<template>
    <h1>cancel page</h1>
    <a href="/">go back</a>
  
</template>

<script>
export default {
name:"Cancel"
}
</script>

<style>

</style>