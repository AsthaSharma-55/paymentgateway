<template>
    <h1>payment successfull</h1>
  <a href="/">buy agin</a>
</template>

<script>
export default {

    name:'Success'
}
</script>

<style>

</style>