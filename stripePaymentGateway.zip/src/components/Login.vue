<template>
  <h1>Login</h1>
</template>

<script>
export default {
name:"Login"
}
</script>

<style>

</style>